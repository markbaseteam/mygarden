---
uuid: 2022118133914
tags: [conviso/article]
aliases:
dates:
created: 2022118133914
source:
author: Rodrigo Rocha
---


# Artigo - Porque o PO deve priorizar segurança durante as sprints?


Quando falamos de desenvolvimento de software sempre ouvimos falar que um dos grande problemas de segurança é a visão de que segurança se "se pensa depois, primeiro vamos entregar a aplicação". 

Bom, essa visão tem um série de problemas, mas hoje vamos falar sobre um outro ponto que poucos estão atentos: _Software Supply Chain_.

Pensa que segurança é um ponto que pode ser trabalhado depois não só aumenta a sua lista de coisas a resolver, tradicionalmente o backlog, como também termina por minar a confiança do seu cliente com seu trabalho. Vou tentar colocar aqui neste artigo alguns pontos que podem ajudar a entender porque o planejamento de segurança na sprint também deveria ser considerado importante e deveria fazer parte da dinâmica de um _Product Owner_.

Uma pesquisa realizada pela CloudBees aponta que 95% dos executivos de C-Level estão mais preocupados em proteger as suas cadeias de suprimento para a produção de suas aplicações. No entanto, mesmo com essa visão mudando ainda temos alguns caminhos a percorrer, um bom exemplo foi quando os eventos envolvendo a Log4J levaram várias equipes de desenvolvimento a realizar buscas por componentes afetados. Claramente o uso de ferramentas usando conceitos de SBOM teriam resolvido este ponto de forma muito rápida e prática.

Ainda, em outra pesquisa desta vez realizada pela Venati, temos 61% de executivos que entendem que preocupação com _Software Supply Chain_ deve ser de responsabilidade da equipe de TI e temos 31% entendendo que essa responsabilidade deve ser dos times de desenvolvimento. Além disso, 94% destes mesmos executivos entendem que o _vendor_ deveria ser punido por estas fragilidades em seus sistema.

Depois de todos estes pontos, podemos entender que estamos diante de uma situação bem clara: Segurança de software deve ser incorporado no processo de desenvolvimento o mais cedo possível. O planejamento dos aspectos de segurança de um software podem permitir às empresas a construirem suas soluções de forma mais segura, prática e efetiva.

## Planejamento de Segurança durante as sprints

Entendendo que a definição de segurança de um software deve caminhar desde o início da aplicação, passando por sua definição de requisitos e seu desenho como solução, ainda assim temos um ponto bastante forte a considerar.

O modelo ágil, por definição, pode ser contrário ao processo de mitigação de riscos ou mesmo para aprodução de cobertura de segurança. Modelos ágeis usam o Scrum como framework, as atividades e tarefas são quebradas em atividades que podem ser realizadas dentro de um tempo fixo, chamadas de sprints. 

Todas as atividades a serem desenvolvidas vem de uma lista chamada backlog, que por definição é uma lista composta de requisitos funcinais e também não-funcionais. A partir desta lista as atividades são retiradas e trabalhadas e quando a sprint se encerra, os cards são colocados como fechados, isso para mostrar progresso no processo de construção da aplicação. Fato é que, neste cenário o mais importante é o tempo!

Quando se coloca segurança dentro do processo, e se criam cards para representar esta necessidades, é possível que o backlog seja impactado, tendo muitas outras atividades, e que dentro do tempo determinado, fechar aquelas atividades ficaria inviável. 

Este é o ponto, chegamos onde devemos começar a falar sobre a importância de termos _Product Owners_ realmente interessados, focados e proativos quando o tema é segurança de aplicações.

## Afinal, onde atuaria um _Product Owner_ em um SDLC?

Primeiro vamos relembrar qual é a função de um _Product Owner_.

Dentro do processo de desenvolvimento a figura do _Product Owner_ ou simplesmente PO tem como função de definir o backlog, e ainda, converter as histórias de usuários ou mesmo os caso de uso do produto em requisitos funcionais e em requisitos não-funcionais, basicamente é isso.

Quando, por alguma razão o _Product Owner_ traz algum ponto de segurança para a sprint, esse geralmente recebe menos importância que as definições e execuções de requisitos funcinais ou não-funcionais.  Ainda, temos um aspecto cultural ainda muito forte, é normal equipes de desenvolvevimento terem o entendimento que aspectos de segurança devem ser validados e vistos por times específicos, e que outros podem realizar atividades de _code review_, por exemplo.

Mas eles esquecem de uma coisa muito importante, e para isso vou tentar responder primeiro fazendo uma pergunta:

Qual seria então o foco principal de modelos ágeis de desenvolvimento? Não seia, dentre vários outro o ganho de tempo para o desenolvimento?

Pois bem, se pensarmos que outros times deveriam se preocupar com segurança e depois realizar os testes, o que aconteceria com as vulnerabilidades e ou erros de codificação encontrados? Estes não voltariam para o time de desenvolvimento corrigir? E o que aconteceu com o tempo que foi ganho no primeiro momento? 

Eu respondo: Foi perdido com o re-trabalho!

Então, respondendo à pergunta de nosso tópico, o PO deveria estar preocupado em entender as necessidades de criação de histórias e casos de uso mas também deveria estar preocupado em incluir nestes pontos já os requisitos de segurança, já pensando em realmente aproveitar da melhor forma possível o tempo de seu time.

Então, novamente tudo se resume a um uso efetivo e eficaz do tempo!

E você pode estar se perguntando agora: Ok, mas quais seriam os reais benefícios de eu tempo meu _Product Owner_ planejando segurança nas sprints?

Bom, vou tentar listar alguns aqui.

Não sei quanto a vocês mas para mim fica bem claro que um dos ganhos principais seria de tempo. Teríamos muito menos retrabalho. Precisaríamos trabalhar menos em correção de pontos que claramente já poderia ter sido desenvolvidos de forma correta.

Outro ponto que vejo como bem claro é quanto a posturas de _compliance_ que já seriam atendidas nos primeiros estágios de um desenvolvimento, isso poderia evitar uma série de problemas, se todos soubessem o que realmente devem construir.

Vejo outro, esse tipo de postura demonstraria para seu cliente uma visão e preocupação em ter um produto seguro, que tem como foco a manutenção da sua privacidade, acho que isso já é por si só uma coisa muito interessante a ser colocada aqui, mas vamos em frente.

Por último mas não menos importante, você enquanto desenvolvedor já construiria um software com base sólidas de segurança. 

Mas, e como eu enquanto _Product Owner_ posso fazer essa priorização?

Bom, vejo duas formas que isso pode ser apresentado dentro do processo de desenvolvimento. 

O primeiro é imaginar que você terá um momento exclusivo para o planejamento de segurança da sprint. Neste momento, você deve identificar tudo que será realizado dentro da sprint, user stories ou mesmo product use case, e já construa a visão de segurança necessária para a sprint, ou seja, teremos sprints exclusivas de segurança onde teremos code review, revisão de design ou de arquitetura e até mesmo para a construção de requisitos de segurança.

O segundo modelo que imagino é quando os requisitos de segurança são incluídos nas atividades das sprints regulares. Aqui acontece o processo normal de planejamento das atividades, com as definições de requisitos que serão entregues mas, neste caso também teremos atividades focadas em segurança da aplicação.

Bom, independente se você vai usar uma das duas visões que coloquei aqui uma coisa não pode ser ignorada, os _Product Owners_ não podem mais ignorar a segurança das aplicações, elas precisam fazer parte do seu dia a dia.

E você o que pensa sobre isso?



##### Se also
- https://www.toolbox.com/it-security/application-security/articles/sprint-planning-security-concerns/#SocialMediaInterests


---
Backlink: [[030 - AppSec MOC]]