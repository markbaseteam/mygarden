---
uuid: 202111102011
tags: [learning/appsec/api,learning/appsec/architecture,learning/appsec/rest-api,learning/appsec/soap,learning/appsec/json]

dates:
- created: 2021-11-12+22:54
source:
- [https://www.internetsociety.org/deploy360/tls/basics/]
- [https://www.youtube.com/watch?v=cuR05y_2Gxc]
author: Rodrigo Rocha
---

# API - Application Programming Interface


# O que é API?

API - é uma sigla que significa Application Programming Interface

-  É um software que permite a troca de informações entre dois ou mais sismtemas.
-  É uma forma de permitir que sistemas de terceiros possam ter acesso a informações de dentro dos sistemas de uma empresa sem ao menos entrar em contato com os sistemas internos.
-  O que garante a troca de informações é um ponto de contatoque muitas vezes é chamado de interface ou mesmo _end point_.


### Como uma API funciona

Uma API serve como uma interdace entre sistemas externos e internos e busca em sistemas internos as informações que são solicitadas por sistemas externos. A entrega destas informações se dá pela API e não o contado direto entre os sistemas.

O desenvolvedor do sistemas externo não precisa saber como o sistema internos funcina, apenas precisa conhecer as interfaces de comunicação da API e como ele deve fazer a requisição das informações.

De forma geral há 4 etapas sendo executadas na comunicação entre o sistema externos e internos, e estão listadas aabaixo.

1. O sistema externos inicia a chamada à API;
2. A API entende a requisição e comunica com o sistema interno;
3. O sistema interno responde a está solicitação;
4. A API devolve a informação ao sistema externo solicitante.

Um dos pontos iniciais que a API pode trazer é a segurança, pois atua entre os sistemas, o que pode garantir mais uma camada de proteção para o sistema interno. Há, por parte da API alguns mecanismos de proteção como princípios de autenticação e ou limitação de conexão e uso.

### Por que precisamos de APIs?
Ao desenvolver um novo sistema e ou atualizar um existente, o processo de incluir uma API ao design da solução pode trazer uma série de benefícios:

1. **Melhorara a colaboração**: Mesmo tendo uma quantidade de sistemas sendo criados e muitas vezes dentro da mesma estrutura, a grande maioria continua trabalhando de forma isolada. O uso de APIs pode permitir que estes sistemas troquem informaçõe e ou trabalhem em algum formato colaborativo.
2. **Facilidade de Inovação**: O uso de APIs permite a comunicação com uma quantidade maior de parceiros e permite que os desenvolvedores possam compartilhar e trocar mais informações de forma mais fácil e controlada. 
3. **Monitizaão dos dados**: Com o uso de APIs é possível fornecer uma quantidade de informações muito grande e sendo estas informações relevantes, isso pode transformar estes dados em receita para um negócio.
4. **Mais segurança**: Pelo que já vimos, a API criar uma nova camada de proteção que existe entre os sistemas internos e externos.  A segurança das API ainda pode ser melhorada pelo uso de protocolos de conexão segura como [[20211112100921 TLS - Transport Layer Security|TLS]], ou mesmo o uso de [[tokens de autenticação]], [[assinaturas digitais]] ou mesmo o uso de [[Gateways de API]]. Sem falar no uso correto de [[práticas de gerenciamento correto de API]].
 
### Exemplos mais comuns de APIs

Pelo crescimento que temos visto das APIs no modelo de desenvolvimento atual, o uso de APIs pode ajudar de diversas formas e aqui estão alguns exemplos de uso para as APIs:

1. **Formas de autenticação (Login)**: O uso de APIs pode permitir que o processo de logins seja realizado por uma aplicação intermediária ao sistema e ainda fornecer para outros sistemas a possibilidade de autenticação.
2. **Pagamentos**: APIs podem fornecer a capicidade de sites usarem as funcionalidades de outros sistemas como o PayPal para realizar seus processos de comércio.
3. **Google Maps**:  É um dos exemplos mais comuns para o uso de API. O uso de APIs do Google permitem entre outros vários usos a utilização de dados de geoprocessamento para serem usado em outras aplicações.


### Tipos de APIs

Hoje temos que a grande maioria das APIs são aplicações feitas para a Web e permitem que outros sistemas possam entregar e compartilhar informações pela web, tipos:

1. **APIs abertas**: São APIs que estão publicamente expostas e podem fornecer informações por meio de _end points_ predefinidos e com respostas também determinadas. 
2. **Parceiros**: APIs criadas com o objetivo de trocar informações entre parceiros e ou "sistemas" fehcados de negócio.
3. **Internas**: Mesmo que a grande maioria das APIs sejam expostas, ainda há grande quantidade de APIs internas e que servem apenas como uma forma de comunicação entre sistemas internos, dentro de uma mesma organização.
4. **Compostas**: Permite que sistemas possam acessar vários _end points_ apenas com uma única requisição. São muito utilziadas para estruturas de [[Microserviços]].


### Tipos de protocolos
Com o grande crescimento do uso das APIs, também surgiu uma grande quantidade de protocolos que tentam entregar funcionalidades diversas. Esses [[protocolos]] tentam entregar as informações de forma estruturada.

1. **[[SOAP]] (Simple Object Access Protocol)**: É um protocolo que tem como base de troca de informações o XML. e pode usar o HTML e ou SMTP como protocolos de comunicação.
2. **XML-RPC**: Também usa o XML como base de transporte de informações, mas é um formato de troca de dados mais antigo que o SOAP. As vantages são sua simplicidade e a leveza para as comunicações.
3. **[[JSON]]-RPC**: É um protocolo similar ao XML-RPC, por que ambos produzem chamadas de procedimentos remotos (RPCs), o que difere este protocolo é o uso do JSON como base para a transmissão.
4. **[[REST]] (Representational State Transfer)**: É um conjunto de princípios de arquitetura para API web, o que nos mostra que não há um padrão estabelecidos. Para ser considerada uma [[REST API]], esta interface deve se adequar a alguns princípios de arquitetura. É possível a construção de uma REST API usando como base o padrão SOAP mas, não é o que acontece normalmente.


### APIs, serviços web e microserviços
Um [[web service]] é um componente que participa de vários sistemas que pode ser acessado por endereços web, sendo assim, um serviço web necessariamente precisa de uma conexão de rede, e como cada web service está exposto e forncendo informações, cada um web services é uma API, mas nem toda API é um web service.

Quando usamos APIs, é comum que duas arquiteturas sejam as mais usadas:

1. **[[SOA]]**: É um tipo de arquiteutra onde são usadas aplicações menores, e que normalmente estão distribuídas em serviços serparados dentro da rede. Normalmente a arquitetura SOA é implementada por web services, usando protocolos comuns.
2. **[[microservices]]**: É uma arquitetura que utiliza web services em sistemas menores e autônomos. É uma forma de criar sistemas baseados em sistemas menores e indepentes o que facilita os testes, manutenção e evolução, visto que apenas o componentes necessários será trabalhado.


### APIs e Arquiteturas de Cloud

A construção de  Aplicações Nativas de Cloud é verdade por garantir a interconexão de vários sistemas e outros aplicativos baseando-se em APIs, para que com isso seja possível o compartilhamento de dados e informações.

É comum que web services dentro de uma arquitetura de microserviços usem um protocolo comum que facilite a troca de informações, um exemplo pode ser o uso de REST API. Isso possibilita a inclusão, exclusão e ou modificação de web services sem que gere impacto na estrutura já montada.


## Referências:
[Nicole Van - API](https://notes.nicolevanderhoeven.com/API)
[Application Programming Interface (API)](https://www.ibm.com/cloud/learn/api)
[API Management](https://www.ibm.com/cloud/learn/api-management)
[REST API](https://www.ibm.com/cloud/learn/rest-apis)
[SOA vs. microservices: What’s the difference?](https://www.ibm.com/cloud/blog/soa-vs-microservices)
[What is API Security?](https://www.youtube.com/watch?v=Cpr7oUMLrrM)

---
Backlink: [[030.4 Archtecture MOC]]
