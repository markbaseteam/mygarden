---
uuid: 20220106130132
tags: [conviso/article]
aliases:
dates:
created: 20220106130132+13:27
source:
author: Rodrigo Rocha
---

# 20220106012739 RASP no cenário de AppSec


A construção de uma aplicação segura envolve muitos aspectos, e um destes aspectos se dá no momento em que a aplicação está servindo ao seu propósito, está disponível ao usuário. Precisamos manter a segurança de uma aplicação já em produção. Neste ponto, entra em cena um conceito bem interessante, você já ouviu falar de Runtime Application Self-Protection ? Se não ouviu, vamos tentar ajudar neste artigo.

Vamos começar do início. O que é RASP?

Segundo o Gartner, RASP é definido  “a security technology that is built on or linked into an application runtime environment, and is capable of controlling application execution, and detecting and preventing real-time attacks.”

E desta forma podemos dizer que RASP é uma tecnologia que protege a aplicação em tempo de execução, e tem como características a possibilidade de controlar a aplicação em tempo de execução detectando e prevenindo ataques em tempo real.

Entendendo o que vem a ser o RASP vamos falar um pouco mais sobre ele.

Bom, mas como essa tecnologia funciona? Essa tecnologia funciona por meio de uma agente integrado a aplicação, e este agente busca manter e observar o controle sobre o comportamento da aplicação, o que permite que ele tome algumas ações imediatas, sem que fique aguardando que este comportamento se "encaixe" em uma assinatura, o que acontece normalmente com ferramentas reativas.

O fato desta tecnologia agir dentro da aplicação, leva à pergunta de que seria possível então abrir mão das demais ferramentas de testes e deixar apenas o RASP atuando na proteção da aplicação, correto? Bom, não, não podemos.

O RASP pode ser mais uma das camadas de proteção que uma aplicação deve ter para buscar o mais alto grau de segurança, e não deve ser entendido como uma solução definitiva e que pode substituir as outras. Ela é complementar.

Temos que lembrar que alguns tipos de problemas são detectados apenas por testes manuais, como por exemplo lógica de negócios, isso demonstra que não podemos de forma alguma entender como soluções de "bala de prata" qualquer produto ou tecnologia. Temos que entender e aproveitar o melhor que cada uma pode nos oferecer.

Da mesma forma, fragilidades e vulnerabilidades não podem receber correções diretamente durante o processo de execução. 

RASP e IAST são tecnologias semelhantes, pois ambas trabalham no servidor web e estão ligadas diretamente à aplicação. No caso do RASP, essa é uma tecnologia otimizada para ser executada em ambientes de produção, por isso podem produzir menores impactos durante um processo normal de uso da aplicação.

Mas, eles diferem basicamente no seu objetivo, pois o IAST executa uma série de testes e quando finalizado o seu teste ele informa as vulnerabilidades que foram identificadas. Já o RASP não executa um scan para buscar as vulnerabilidades, ele é executado em background observando o comportamento da aplicação, buscando anomalias tanto no comportamento quanto no tráfego.

De forma geral temos dois modelos de execução do RASP. O primeiro modo de execução é chamado de Mode de Diagnóstico, e assim que um ataque é detectado ele emite alertas, sem atuar para bloquear o ataque, além da geração de alerta, ele envia as informações do alerta sobre a vulnerabilidade para um dashboard.

O segundo modo é chamado de Modelo de Auto-Proteção, e neste modo há uma ação mais reativa, fazendo com que, ao detectar uma ação que pode gerar dano à aplicação, o RASP para a requisição que está executando a ação.

Outro ponto que pode surgir quando falamos de RASP é o quanto ele se parece ou não com uma solução de WAF. 

Soluções de WAF são tecnologias diferentes, pois em primeiro lugar são aplicações que não estão ligadas diretamente à aplicação, e servem mais como um ferramenta intermediária entre a aplicação e o acesso do usuário, buscando identificar padrões de ação para evitar um problema do lado da aplicação. 

Não queria aqui entrar em mais detalhes sobre o WAF, e gostaria muito de ter o seu comentário e pensamento sobre esta tecnologia e quem sabe suas semelhanças e diferenças com o WAF, por exemplo. Que tal nos ajudar nos comentários?


##### Se also
- https://www.synopsys.com/blogs/software-security/runtime-application-self-protection-rasp/
- https://dzone.com/articles/how-rasp-complements-application-security-testing
- https://zcybersecurity.com/what-is-rasp-security-runtime-application-self-protection/


---
Backlink:  [[030 - AppSec MOC]]