---
uuid: 202207252240
tags: [appsec, samm, unfinished]
aliases:
- "O que é SAMM Agile?"
- "SAMM Agile"
dates:
  created:  202207252240
  modified: 202207252240
source: https://owaspsamm.org/guidance/agile/
author: Rodrgio Rocha
---

# SAMM Agile
Quando falamos de processos de desenvolvimento nos dias de hoje podemos imaginar que em algum momento vamos ter que entender  ou mesmo explicar quando o modelo do SAMM pode ser empregado em uma estrutura de desenvolvimento [[ágil|Modelos Ágeis]].

Do ponto de vista de desenvolvimento, as etapas do processo de desenvolvimento são as mesmas quando olhamos para os modelo acadêmicos, usados para explicar como o desenvolvimento acontece e as novas metodologias mais ágeis.

Primeiro precisamos entender que o [[As práticas do SAMM|SAMM]] é um framework desenvolvido pela OWASP e tem como foco principal ajudar na estruturação de um processo de desenvolvimento seguro. Como um framework agnóstico, não há nada diretamente relacionado com modelos de desenvolvimento ágeis.

A dúvida, quando falamos do SAMM, é como este modelo vai se encaixar na estrutura atural de desenvolvimento, mais focada em um processo mais ágil. Neste aaspecto, precissamos entender como as várias etapas do SAMM pode ser usada nas histórias, sprints, definições de casos de abuso e outras.

![[Pasted image 20220725224246.png]]

## General

### Como manter a qualidade frente à agilidade

Um dos principais questionamento que o modelo do SAMM enfrenta é que, dentro de um modelo de agilidade, a garantia da qualidade não pode tornar o processo burocrático, e portanto não deve influenciar na agilidade das entregas.  

> [!info]
> O grande desafio para o SAMM, e quem o aplica, é introduzir as suas práticas sem tornar o processo burocrático, mais lento e ainda assim mantendo a qualidade de software.

Para que esse pensamento seja verdade, temos que nos atentar para dois pontos básicos.
1. A construção do software deve ser segura
2. E encontrar os erros com a máxima eficiência.

#### Prevenção
- O uso de tecnologias sólidas, assim como frameworks que possa atender o máximo de segurança possível.
- Os requisitos restantes são claros e aplicados de forma situacional, tanto quanto possível, para reduzir o número de requisitos que precisam ser tratados o tempo todo.
- Todos os envolvido no processo de desenvolvimento, incluindo o Product Owner, deve ter um entendimento claro e assumir suas responsabilidades dentro do processo.
- Os desenvolvedores devem ter uma noção clara e viável das instruções. O qaue também torna situacional cada uma delas.
	- Listas curtas e claras de requisitos.
- A manutenção deve ser tratada com atenção, para facilitar a manutenção.

#### Lutando
- Usando o máximo de automação possível.
- A validação manual ainda se faz necessária, mas deve ser feita de forma inteligente usando modelos incrementais. Deve existir um foco em riscos.

O modelo do SAMM tem como objetivo ajudar a entregar estas visões e fazer com que isso aconteça.

### Um Processo de Maturidade conflita com um modelo Ágil?
Um dos primeiros pontos é perceber que o uso de um Processo de Maturidade, aparentemente, vai de encontro ao que prega o Manifesto Ágil. Fica evidente que um não faz muito sentido com o outro, pois o modelo prega a construção de processo e o manifesto coloca as pessoas acima dos processos.

No entanto, um olhar mais aprofundado nos conceitos de modelos ágeis vai nos mostrar que a metodologia ágil não desqualifica o uso de processos ou mesmo de documentação, apenas busca diminuir o máximo possível o seu uso.

Na verdade, um modelo de maturidade pode entregar uma ajuda muito grande ao modelo de desenvolvimento ágil, visto que pode pode ajudar a entregar uma dinâmica bem estruturada e com processos adequados ao desenvovimento.

## Governance - Education and Guidance

### Autonomia do time
Um dos pontos mais importantes para times que abraçam a metodologia ágil é garantir a autonomia dos times, pois assim é possível ter mais agilidade e tornar o processo de desenvolvimento menos centralizado.

Este ponto torna ainda mais desafiador o processo de implementar um conjunto de práticas de maturidade dentro de uma escala corporativa. O pensamento é smples, pois se o processo de maturidade é uma base de entendimento para ser implementado, como isso impacta em um modelo que busca aumentar a autonomia.

Durante o processo de implementação do programa, deve ser determisnado a importancia da continuidade da autononia do time, se isso for entendido como visável e real, a equipe de implementação deve entender que times diferentes tem graus de maturidade diferentes e portanto devem ser entendidos com grupos específicos.

No mesmo sentido, é importante que times diferentes tenha a oportunidade de aprender com outros times. Isso impacta diretamente no resultado final pois torna o processo de implementação mais "executável".

Dentro do objetivo de ter dentro do processo os conceitos de segurança ao desenvolver, se faz necessário ter momento onde o tema seja apresentado e mantido. Momentos como reuniões de refinamento e de retrospectivas são momentos possíveis de serem usados. Com o tempo os times vão aprendendo a identifiar quais preocupações de segurança vão exigir muito esforço e tempo, e podem estar sendo substimadas.

A presença do Securtity Champion dentro deste processo pode ser de muita ajuda, pois durante as reuniões ele pode agir como um ponto focal para temas relacionados com segurança de aplicações.

### Segurança como responsabilidades compartilhada
Por conceito, a Segurança de Aplicações deve ser pensado desde o início da construção e isso também é foco para metodologas ágeis e também deve ser observado.

Durante as sprints é importante entender que nã há tempo suficiente para um foco grande no conceitos e princípios de segurança, mas eles devem existir. Se pensarmos que em um modelo ágil, a cada interação deveríamos ter testes completos e extensos, teríamos novamente um modelo mais lento e onde haveria disputas constantes entre o time de segurança, desenvolvimento e o próprio dono do produto.

Esse aspecto de ter todos como responsáveis pela segurança da aplicação traz uma visão mais de que os profissionais de segurança irão agir mais como consultores do que como __quality gates__ dentro do processo. 

Mesmo que todos os cuidados sejam tomados, ainda assim em algum momento pode acontece de que os aspectos de segurança sejam vistos como __bottleneck__ e neste momento é importante que o time tenha sido estimulado a buscar conhecimento e a ter profissionais de referência para acionar. Desta forma podemos dizer que o processo pode se tornar escalável.

> [!alert] Alerta 1 - Segurança isolada
> Em algumas organizações os aspectos de segurança são validados pelo "departamento de segurança" que ao identificar vulnerabilidades se vê obrigado a convencer áreas de negócio a corrigir estes pontos. Isso acontece muito em negócio os o valor do produto/negócio é medido por quantidade de _features_ e não pela segurança. 
> Caso sejam usadas demonstrações de produtos, estes momentos devem ser usados para demonstrar como os aspectos de segurança podem ser tratados ao lado dos recursos de negócios.  

### Security Champions
Por definição, a figura do Security Champion é a ligação entre os times de desenvolvimento e os times de segurança. Eles funcionam como pontos de contato para questões sobre segurança, neste caso segurança de aplicações. 

A sua presença tem como função básica permitir que os times de desenvolvimento criem uma cultura de desevolvimento seguro, e isso pode também acontecer quando eles retiram do caminho impedimentos que poderiam impedir o time de desenvolver um software de maneira segura.

Se tomar como base que dentro de times ágeis a colaboração é um dos pontos mais importantes, a presença de um Security Champions é um dos pontos a serem buscados durante o processo de implementação.

> [!alert] Alerta 1 - Confiança demasiada no héroi
> Devem ser tomados cuidados para que as questões de segurança não sejam delegadas apenas a uma única pessoa. O Security Champion pode ser um ponto de ajuda no que form possível mas, as responsabilidades não deve ser exclusiva dele.

> [!Alert] Alerta 2 - Um hério silencioso
> Mais importante do que aspectos de conhecimento técnico, o Security Champion deve buscar aprender e sabe se comunicar e transferir conhecimento. Por isso, sabe escolher seus Security Champions é muito importante.

- Um ponto de interessa pode ser a leitura do material de Organização e Cultura do SAMM.
	- https://owaspsamm.org/model/governance/education-and-guidance/stream-b/


## Governance - Strategy and Metrics

### Métricas
Uma característica primordial de um modelo ágil é a frequencia das verificações e um processo contínuo de aquisição de feedbacks. 

Aqui vale a frase do Peter Drucker "**Você não controla o que você não mede.**".

Tendo isso sendo entendido, para que você tenha segurança na agenda dos times de desenvolvimento e possa melhorar e aumentar a maturidade dos resultados, se faz necessário medir vários aspectos do processo.

De forma ideal, estas medidas, ou métricas devem ser apresentadas em um único ponto, um dashboard por exemplo, desta forma a transparência aparece vantagem importante para o processo. 

- Um bom ponto de partida seja a leitua do material sobre métricas no site do SAMM.
	- https://owaspsamm.org/model/governance/strategy-and-metrics/stream-b/

## Design - Threat Assessment

### Modelagem Incremental de Ameaças
No manifesto Ágil tem uma parte do texto que diz "working software is more important than comprehensive documentation". Entender o conceito por trás deste texto é imporante mas, existem momentos onde devemos ser um pouco mais rigorosos.

Este momento é quando tratamos de ameaças ao software. 

Olhar para as ameaças implica em entender e conhecer a aplicação, bem como em entender e conhecer o contexto onde essa aplicação estará. Para isso não há como não ter documentação. O objetivo do SAMM dentro de um modelo ágil não é engessar o processo de desenvolvimento mas sim entregar estrutura suficiente para que o resultado final seja o adequado.

> [!important] Threat Modeling
> Não se pode descartar a Modelagem de Ameaças. Temos que implementar a sua execução de forma eficiente e talvez essa forma seja ela sendo incremental.

Em uma visão clara sobre Modelagem de Ameaças, temos que entender que essa prática tem como finalidade permitir aos times de desenvolvimento e segurança a criação de cenários de possíveis ameaças às aplicações, permitindo assim que requisitos de segurança sejam identificados. Essa visão claremente permite aos times reduzirem as possibilidades de erros no processo de desenvolvimento do software.

É possível estruturar a execução de Modelagem de Ameaças de forma a não ser necessário a execução completa de uma modelagem todas as vezes. Esse processo pode ser feito de forma incremental, assim que o software for evoluindo. 

A cada história pode ser gerado uma nova modelagem de forma incremental, aumentando o entendimento sobre os cenários e possíveis novos requisitos. Neste ponto, se o time entende que o processo de modelagem é importante para a contrução da aplicação, em algum momento pode ser executado uma modelagem mais completa levando em conta tudo que foi construído.

Se a execução incremental for implementada, podem ser executadas 4 etapas de forma bem clara e simples, e estas etapas podem ser explicadas nestas 4 perguntas.
1. what are we doing?
2. what can go wrong?
3. what are we doing to defend against threats
4. they were validated in previous steps?

Um ponto importante é o envolvimento do Produtc Owner, pois ele vai dar uma visão clara e rápida de vários aspectos relacionados ao software. 

> [!alert] Alerta - Apenas Modelagem de Ameaças
> A realização de Modelagem de Ameaças não pode ser entendido como a única forma de entregar segurança para o desenvolvimento de aplicações. É importante que haja dentro da estrutura de desenvolvimento uma série de requisitos já identificados e que podem ser entendido como requisitos básicos para serem utilziados de acordo com determinadas situações. 

- Um material que pode ser interessante é o descrito na parte de Threat Modeling do SAMM.
	- https://owaspsamm.org/model/design/threat-assessment/stream-b/


## Design - Security Requiriments

### Selecionando e Preparando Requisitos
Dentro de um processo de desenvolvimento ágil, alguns requisitos precisam e devem ser revisados a cada sprint. Para que isso seja prático e verdadeiro, estes requisitos devem ser realistas com o escopo que estão protegendo, sem essa visão serão rapidamente esquecidos.

O objetivo é criar histórias/processos que seja o suficiente para realizar sua tarefa, isso visa principalmente minimizar o impacto destes testes dentro do processo de desenvolvimento.

#### Por sistemas
Mesmo antes de uma aplicação ser iniciada, requisitos já podem ser identificados quando há uma lista de requisitos mínimos já criada. Estes requisitos podem muito bem estar realcionados com requisitos de segurança ligados ao ramo de atuação ou mesmo exigidos por regulamentações.

Para que estes requisitos sejam realidade, devem ser constantemente revistos e podem ser auxiliados por um processo claro de análise de risco.

Requisitos não-funcionais podem ser entendidos para pontos como seleção e preparação:
- Não aplicável ao contexto
- Aplicável mas com risco aceito
- Coberto por tecnologia usada
- Precisa de instruções genéricas ou mesmo histórias específicas

Depois que há a seleção e preparação dos requisitos genéricos, se faz necessário termos claramente definidos quais são os pontos que devem ser observados para termos um Definition of Done - DOD. Se já temos essa lista de requisitos e suas definições de pronto, podemos disponibilizar para que sendo necessários e relacionada com systemas específicos, possam selecioandos e implementados seguindo o já definido.

Outro ponto que pode ser entendido como vantajoso é que, se já temos um conjunto de requisitos selecionados e preparados, estes podem claramente servir como base para estruturadas de capacitação e treinamento.

#### Por história
Uma outra forma de ideitificarmos e escolhermos requisitos é quando fazemos isso durante a criação de uma história ou mesmo durante a construção do refinamento. Se for necessários, a presenção do Security Champion, ou um especialita em segurança pode ser um bom ponto de apoio.

Há algumas formas que os requisitos podem ser identificados:
- Usando a lista de requisitos já identificada.
- A experiência do time e do Security Champion
- Usando Casos de Abuso
- Usando Modelagem de Ameaças

##### Instruções
Quando criamos requisitos, o que estamos criando são um conjunto de regras que um software deve seguir para que esteja de acordo com algum "desejo". Quando falamos sobre requisitos de segurança o princípio é o mesmo, apenas que devemos entender que estes são requisitos de segurança da aplicação.

A definição destas regras ou requisitos, ajuda ao time de desenvolvimento ter uma noção clara do que usar e do que não usar em um determinado momento, ou mesmo planejar o uso em um outro momento. O foco é permitir que o desenvolvedor tenha um conjunto já definido e estruturado de regras, requisitos, que possam ser usados quando necessário.

A imagem a seguir pode ajudar no entendimento:

![[Pasted image 20220725224329.png]]

> [!alert] Alerta 1 - Muitos Requisitos
> Devemos ter cuidado com a quanditdade de requisitos. Ter muito requisitos pode dificultar o que perguntar ao desenvolvedor. A quantidade de requisitos também pode ser muito para ser testado a cada ciclo. 
> O foco é conseguir ter a quantidade de requisitos adequada e suficiente para aquele momento.

> [!alert] Alerta 2 - Esquecer Frameworks
> Devemos lembrar que muitas vezes os frameworks e bibliotecas já podem atuar como primeira estrutura de proteção, e portanto devem ser usados com este princípio também. Estes próprios companentes podem e devem ser usados para reforçar a estrutura de segurança da aplicação.

>[!alert] Alerta 3 - Abuso no COS - [[Conditions of Satisfaction]]
> Se o time trabalha com Conditions of Satisfactions, estes não devem ser usados para representar requisitos de segurança, pois estes são mais relacionados com comportamentos funcinais da aplicação. Ainda, não podemos colocar como DOD os requisitos da história pois estes são específicos e são independentes da história dos usuários.

> [!alert] Alerta 4 - Apenas Modelagem de Ameaças
> Não podemos deixar aconter o entendimento de que apenas realizando a Modelagem de Ameaças termos conseguido inserir segurança no desenvolvimento. Para um desenvolvedor é difícil ter outra visão que não a de criação da aplicação, a visão de um atacante é fora da "realizadade" do desenvolvedor, por isso é importante que já existam alguns requisitos definidos e estruturados.

#### Requisitos nas histórias
Quando criamos as histórias, temos que nos lembrar que elas devem ser recheadas de requisitos não-funcionais, para que assim se tenha uma visão clara dos critérios de aceite, tudo baseado no resultado do trabalho esperado.

Isso é importante pois mostra aos desenvolvedores o que deve ser levado em consideração, além de mostrar o que e como serão os testes. Além de ajudar no planejamento do trabalho.

Construir as histórias com as informações ncessárias é feita durante o processo de planejamento do backlog, e se necessário pode contar com a ajuda de um especialista de segurança, isso se os desenvolvedores tiverem dificuldades com os dados que vão para as histórias. 

Há várias formas de se coletar os requisitos, entre eles podem ser:
- Gatilhos: Neste caso a lista de requisitos esta em uma lista e é escolhida a partir de um gatilho, como por exemplo o uso de hash sempre que for armazenar senhas.
- Experiência: Especialistas de segurança podem auxiliar na escolha dos requisitos.
- _Abuse Stories_: Com um pensamento de como o sistema pode ser atacado, isso pode ajudar a indentificar os requisitos adequados.
- Modelagem de Ameaças: O uso de modelagem de ameaças é uma das formas de se identificar requisitos.

>[!alert] Ignorar requisitos de segurança
> O segredo para manter a segurança de uma aplicação em um modelo ágil e garatir que o requisitos adequado será escolhido no momento certo. Se as histórias não trazem nada sobre segurança será muito mais fácil esquecer do tema, por isso, sempre deve haver questões de segurança.

>[!alert] Escolhendo requisitos na hora certa
>Escolher os requisitos deve ser feito sempre quando as histórias estão sendo criadas ou mesmo quando o backlog está sendo refinado, nunca devem ser escolhidos durante o processo de planejamento da sprint. 

## Testes baseados em Requisitos

### _Abuse Stories_
Uma história de abuso(Abuse Stories) é uma descrição feita de um cenário da pespectiva de um atacante, e como o sistema poderia ser abusado por meio da exploração de fragilidades.

O objetivo de uma história de abuso é ajudar o time o que poderia ser explorado ou poderia sair errado para a aplicação, e assim poderiam pensar em requisitos de segurança que podem ser usados para mitigar estes cenários. O uso de histórias de abuso são mais simples de usar por que os desenvolvedores estão mais acostumados com o uso de histórias de usuários(user stories).

O uso de histórias de abuso podem ser vantajosas em momentos onde se deve explicar sobre testes de segurança, ou mesmo para explicar para os times que irão realizar _pentests_ sobre quais ameaças os requisitos serão testados.

>[!alert] Não só de histórias de casos de abuso
>Durante o processo de identificação de requisitos, não se deve apenas buscar requisitos utilizando histórias de caso de abuso, deve-se usar outros métodos como gatilhos, experiência ou mesmo modelagem. Isso permite seleções mais diretas e eficientes.

- Um material que pode ser usado para um melhor entendimento pode ser lido em:
	- https://owaspsamm.org/model/verification/requirements-driven-testing/stream-b/


## Testes de Segurança

### Testes Ágeis
Em modelos ágeis os testes acontecem com muito mais frequência e muitas vezes sendo realizadas em um mesmo código ou funcionalidade, isso demonstra cada vez mais a importância da automação para a realização dos testes o que deixaria a realização dos testes manuais mais focado nas mudanças realizadas.

Testes automatizados podem ser realizados por meio de testes programados em um nível de testes unitários ou de integração, ou ainda por ferramentas de deploy. Há um conjunto importante de ferramentas que podem ser usadas como SCA, DAST e SAST.

O importante é notar que a saída de resultados gerados por ferramentas como SCA e SAST podem gerar uma quantidade muito grande de falsos positivos, e precisam ser manualmente validados.

No entanto, nem todos os testes podem ser automatizados. Por exemplo, ferramentas de SAST são limitadas a algumas categorias de problemas em códigos. O tempo necessário para testes manuais pode ser minimisado sendo planejado quando houver mudança no código.

Para metodologias de _code review_ isso quer dizer que as validações feitas durante o teste devem ser focadas apenas nas mudanças que ocorreram no código. É bom perceber que para que isso tenha um resultado desejado, o processo deve ser estruturado e bem administrado.

Para _pentest_ realizados manualmente isso quer dizer que os testes devem ser baseados e focadas em testar funcionalidades que podem ser mais afetadas por mudanças no código, se busca a possibilidade de uma mudança ter introduzido uma fragilidade.

Dentro de um processo ágeil, a contrução modelular se mostra ainda mais importantes quando olhamos para os tests, pois permite que testes sejam realizados em pequenos módulos o que torna o escopo menor e mais facilmente observado quanto às suas mudanças.

Uma boa prática para modelos ágeis de desenvolvimento é que estes tenham dentro dos times de desenvolvimento pessoas que possam realizar testes de QA, o que reduz o tempos e consequentemente o valor investido no processo.

>[!alert] Evitar testes manuais
>Quando se fala em testar aplicações, ambos os modelos devem ser consideados e devem ser realizados tanto testes automatizados quanto manuais.

>[!alert] Pentest tardio
>Um dos problemas com a realização de _pentest_ é a relização destes testes muito tempo depois da construção do software, geralmente depois da publicação, justo quando o retrabalho se torna mais caro.

- Um bom conteúdo que pode ajudar neste entendimento pode ser encontrado em:
	- https://owaspsamm.org/model/verification/security-testing/


#### Final notes
Este material foi preparado tendo como base o documento original escrito por [[Rob Van der Veer]] e pode ser encontrado no link abaixo.
- https://owaspsamm.org/guidance/agile/#General


##### Se also
- https://owaspsamm.org/
- [[As práticas do SAMM]]
